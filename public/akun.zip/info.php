<?php
 
phpinfo();
 
?>